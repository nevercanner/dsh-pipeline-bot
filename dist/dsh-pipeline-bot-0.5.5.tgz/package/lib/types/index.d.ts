import type { Context } from '@deepseek-ai/cordis'

export declare const name: string
export declare const description: string
export declare const inject: readonly string[]

export interface Config {
  /** 插件自身是否工作。群成员是显式加入的，不需要项目级开关。 */
  enabled?: boolean
}

export declare function apply(ctx: Context, config?: Config): void

/** 群成员在线状态。 */
export type MemberStatus = 'live' | 'inactive' | 'missing'
export type MemberRole = 'lead' | 'worker' | 'external'

export interface Member {
  name: string
  sessionId: string
  role: MemberRole
  status: MemberStatus
  cwd?: string
  project?: string
  duty?: string
  product?: string
  seenAt?: number
  lastSeen?: number
}

export interface Message {
  id: string
  ts: number
  from: string
  role: 'lead' | 'member' | 'human' | 'system' | 'external'
  text: string
  kind: 'human' | 'assign' | 'report' | 'system' | 'wake'
  taskId?: string
  targets?: string[]
}

export interface Task {
  id: string
  createdAt: number
  updatedAt: number
  brief: string
  from: string
  targets: string[]
  status: 'dispatched' | 'reported' | 'failed'
  deliveries: Record<string, string>
  reports?: Record<string, string>
  report?: string
}

export interface Group {
  id: string
  title: string
  leadName: string
  members: Array<{ name: string; sessionId?: string; role: MemberRole; duty?: string; product?: string; addedAt: number }>
  messages: Message[]
  tasks: Task[]
  /** 群聊会话 id（宿主里的普通会话）。 */
  roomSessionId?: string
  /** 群聊会话锚定的已有项目（决定它出现在哪个项目的会话列表里）。 */
  projectRoot?: string
  bridgeKey: string
  createdAt: number
  updatedAt: number
}
